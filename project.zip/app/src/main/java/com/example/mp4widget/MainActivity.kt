package com.example.mp4widget

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var titleEdit: EditText

    private fun prefs() = getSharedPreferences("p", MODE_PRIVATE)

    private fun save(key: String, uri: Uri?) {
        if (uri == null) return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs().edit().putString(key, uri.toString()).apply()
        PlayerWidget.refresh(this, false)
    }

    private fun displayName(uri: Uri): String? =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i) else null
            } else null
        }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            save("video", uri)
            // 파일 이름을 기본 제목으로 (아래에서 직접 수정 가능)
            val name = displayName(uri)?.substringBeforeLast('.')
            if (!name.isNullOrBlank()) {
                prefs().edit().putString("title", name).apply()
                titleEdit.setText(name)
                PlayerWidget.refresh(this, false)
            }
        }
    }
    private val pickCover = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        save("cover", it)
    }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        layout.addView(Button(this).apply {
            text = "mp4 파일 선택"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        })
        layout.addView(Button(this).apply {
            text = "표지 이미지 선택 (선택사항)"
            setOnClickListener { pickCover.launch(arrayOf("image/*")) }
        })

        titleEdit = EditText(this).apply {
            hint = "위젯에 표시할 제목"
            setText(prefs().getString("title", ""))
            setSingleLine()
        }
        layout.addView(titleEdit)
        layout.addView(Button(this).apply {
            text = "제목 저장"
            setOnClickListener {
                prefs().edit().putString("title", titleEdit.text.toString()).apply()
                PlayerWidget.refresh(this@MainActivity, false)
                Toast.makeText(this@MainActivity, "저장했어요", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(layout)
    }
}
