package com.example.mp4widget

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private fun save(key: String, uri: Uri?) {
        if (uri == null) return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        getSharedPreferences("p", MODE_PRIVATE).edit().putString(key, uri.toString()).apply()
        PlayerWidget.refresh(this, false)
    }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        save("video", it)
    }
    private val pickCover = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        save("cover", it)
    }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        layout.addView(Button(this).apply {
            text = "mp4 파일 선택"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        })
        layout.addView(Button(this).apply {
            text = "표지 이미지 선택 (선택사항)"
            setOnClickListener { pickCover.launch(arrayOf("image/*")) }
        })
        setContentView(layout)
    }
}
