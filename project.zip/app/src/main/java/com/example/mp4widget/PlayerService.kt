package com.example.mp4widget

import android.content.Intent
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlayerService : MediaSessionService() {

    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                PlayerWidget.refresh(this@PlayerService, isPlaying)
            }
        })
        session = MediaSession.Builder(this, player).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == PlayerWidget.ACTION_TOGGLE) {
            if (player.mediaItemCount == 0) {
                val uri = getSharedPreferences("p", MODE_PRIVATE).getString("video", null)
                if (uri != null) {
                    player.setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
                    player.prepare()
                }
            }
            if (player.isPlaying) player.pause() else player.play()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.release()
        player.release()
        super.onDestroy()
    }
}
