package com.example.mp4widget

import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlayerService : MediaSessionService() {

    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null
    private var loadedUri: String? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                PlayerWidget.refresh(this@PlayerService, isPlaying)
            }

            override fun onPlayerError(error: PlaybackException) {
                PlayerWidget.refresh(this@PlayerService, false)
            }
        })
        session = MediaSession.Builder(this, player).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == PlayerWidget.ACTION_TOGGLE) {
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val uri = prefs.getString("video", null)
            // 파일이 바뀌었거나 처음이면 새로 불러오기
            if (uri != null && uri != loadedUri) {
                val meta = MediaMetadata.Builder()
                    .setTitle(prefs.getString("title", null) ?: "제목 없음")
                    .build()
                player.setMediaItem(
                    MediaItem.Builder().setUri(Uri.parse(uri)).setMediaMetadata(meta).build()
                )
                player.prepare()
                loadedUri = uri
            }
            if (player.mediaItemCount > 0) {
                if (player.isPlaying) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
                    player.play()
                }
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.release()
        player.release()
        super.onDestroy()
    }
}
