package com.example.mp4widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.RemoteViews

class PlayerWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(ctx, false)) }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.mp4widget.TOGGLE"

        fun refresh(ctx: Context, playing: Boolean) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, build(ctx, playing)) }
        }

        private fun build(ctx: Context, playing: Boolean): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget)

            views.setImageViewResource(
                R.id.play,
                if (playing) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )

            loadCover(ctx)?.let { views.setImageViewBitmap(R.id.cover, it) }

            val intent = Intent(ctx, PlayerService::class.java).setAction(ACTION_TOGGLE)
            val pi = PendingIntent.getForegroundService(
                ctx, 0, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.root, pi)
            return views
        }

        // 표지: 직접 고른 이미지 -> 없으면 영상 첫 장면
        private fun loadCover(ctx: Context): Bitmap? {
            val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
            val coverUri = prefs.getString("cover", null)
            val videoUri = prefs.getString("video", null)
            return try {
                if (coverUri != null) {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                    ctx.contentResolver.openInputStream(Uri.parse(coverUri)).use {
                        BitmapFactory.decodeStream(it, null, opts)
                    }
                } else if (videoUri != null) {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(ctx, Uri.parse(videoUri))
                    val f = r.getFrameAtTime(0)
                    r.release()
                    f?.let { Bitmap.createScaledBitmap(it, 400, 400 * it.height / it.width, true) }
                } else null
            } catch (e: Exception) {
                null
            }
        }
    }
}
