package com.example.mp4widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.RemoteViews

class PlayerWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(ctx, false)) }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.mp4widget.TOGGLE"

        fun refresh(ctx: Context, playing: Boolean) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, build(ctx, playing)) }
        }

        private fun build(ctx: Context, playing: Boolean): RemoteViews {
            val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
            val views = RemoteViews(ctx.packageName, R.layout.widget)

            views.setImageViewResource(
                R.id.play,
                if (playing) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )
            views.setImageViewBitmap(R.id.cover, discBitmap(loadCover(ctx)))
            views.setTextViewText(R.id.title, prefs.getString("title", null) ?: "제목 없음")

            val intent = Intent(ctx, PlayerService::class.java).setAction(ACTION_TOGGLE)
            val pi = PendingIntent.getForegroundService(
                ctx, 0, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.root, pi)
            return views
        }

        // 네모난 표지: 둥근 모서리 정사각형에 표지를 꽉 채움 (없으면 회색 네모 + 음반 그림)
        private fun discBitmap(cover: Bitmap?): Bitmap {
            val s = 360
            val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val corner = s * 0.07f
            val rect = RectF(0f, 0f, s.toFloat(), s.toFloat())

            if (cover != null) {
                val side = minOf(cover.width, cover.height)
                val sq = Bitmap.createBitmap(
                    cover, (cover.width - side) / 2, (cover.height - side) / 2, side, side
                )
                val scaled = Bitmap.createScaledBitmap(sq, s, s, true)
                p.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                c.drawRoundRect(rect, corner, corner, p)
            } else {
                p.color = 0xFF404040.toInt()
                c.drawRoundRect(rect, corner, corner, p)
                p.color = 0xFF575757.toInt()
                c.drawCircle(s / 2f, s / 2f, s * 0.38f, p)
                p.color = 0xFF444444.toInt()
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.05f
                c.drawCircle(s / 2f, s / 2f, s * 0.15f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(s / 2f, s / 2f, s * 0.04f, p)
            }
            return out
        }

        // 표지: 직접 고른 이미지 -> 없으면 영상 첫 장면
        private fun loadCover(ctx: Context): Bitmap? {
            val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
            val coverUri = prefs.getString("cover", null)
            val videoUri = prefs.getString("video", null)
            return try {
                if (coverUri != null) {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                    ctx.contentResolver.openInputStream(Uri.parse(coverUri)).use {
                        BitmapFactory.decodeStream(it, null, opts)
                    }
                } else if (videoUri != null) {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(ctx, Uri.parse(videoUri))
                    val f = r.getFrameAtTime(0)
                    r.release()
                    f
                } else null
            } catch (e: Exception) {
                null
            }
        }
    }
}
